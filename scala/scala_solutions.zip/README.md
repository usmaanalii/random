## Programming Exercise: Software Engineer (Scala 1)

Hello, I'd just like thank you for the opportunity to do this exercise. It's
humbling to have been considered by you, I hope I did okay! 

This was my first experience with the language (any statically typed language for that matter), so a lot of the program constructs were
foreign to me, but I can honestly say that I really enjoyed using it, and can't wait to learn more!

### Just a few quick points, to help you understand my work.

- I wrote all of my solutions using the functional approach, as I got the impression this is what you were looking for.
- My experience with functional programming isn't that strong, therefore my solutions may not be the most optimal, this is something I'll be sure to work on.
- I have a repository containing the resources that I used to learn the Scala basics that I needed to do this exercise. It can be seen [here](https://github.com/usyyy/random/tree/master/scala).
- I didn't use the solutions to previous problems whilst solving others, as I felt this would have defeated the purpose of each task.
- My solution for `parsePersonFromString` returns an `Either` type, to access the underlying `Person` object call `.right.toOption` on it, for example `parsePersonFromString("Paul Freeman").right.toOption` will hold `Option[Person]`. I'm not too sure this is what you were looking for, but I feel it met most of the criteria requested.
- I decided to print each element of the results as opposed to the entire List, Set or Map to make it more readable.
- The main resources that I used whilst learning were
    - [Official Scala Documentation](https://docs.scala-lang.org/)
    - [PythonToScala Gitbook](https://www.gitbook.com/book/wrobstory/python-to-scala/details)